# Zed Unity Kit — Claude Code 자동 설치 지시서

> 이 문서는 사람이 아니라 **Claude Code에게 주는 작업 지시서**입니다.
> Unity 프로젝트 루트에서 Claude Code를 실행한 뒤, 이 파일을 따라 설치하라고 지시하세요.

## 전제 조건 확인

1. 현재 작업 디렉토리에 `Assets/` 와 `ProjectSettings/` 폴더가 있는지 확인한다.
   - 없으면 사용자에게 Unity 프로젝트 경로를 물어보고 그 경로를 `<프로젝트>`로 사용한다.
2. `zed-unity-kit.zip` 을 찾는다: 현재 폴더 → 사용자의 Downloads 폴더 순서.
   - 이미 압축이 풀린 `zed-unity-kit/` 폴더가 있으면 그걸 그대로 사용한다.
   - 둘 다 없으면 사용자에게 zip 경로를 물어본다.
3. 임시 폴더에 압축을 해제한다.

## 안전 규칙 (모든 단계 공통)

- 기존 설정 파일을 수정하기 전에 반드시 같은 위치에 `.bak` 백업을 만든다.
- Zed의 settings.json / keymap.json 은 **주석이 포함된 JSONC**일 수 있다. 주석을 보존하며 병합한다.
- 기존 키를 절대 삭제하지 않는다. 충돌이 있으면 새 값을 넣지 말고 마지막 보고서에 충돌 목록으로 알린다.
- 실패한 단계는 건너뛰고 계속 진행하되, 마지막에 반드시 보고한다.

## 설치 단계

### 1단계: Unity 브리지 스크립트

- `unity/Editor/ZedUnityBridge.cs` → `<프로젝트>/Assets/Editor/ZedUnityBridge.cs` 복사
- `Assets/Editor` 폴더가 없으면 생성한다.

### 2단계: 프로젝트 로컬 Zed 설정

- `<프로젝트>/.zed/` 폴더 생성
- `zed/settings-unity.json` → `<프로젝트>/.zed/settings.json`
- `zed/tasks.json` → `<프로젝트>/.zed/tasks.json`
- 대상 파일이 이미 있으면 덮어쓰지 말고 내용을 병합한다.

### 3단계: Zed 사용자 설정 (Windows 기준: `%AppData%\Zed\`)

경로가 없으면 Zed가 설치되지 않았거나 한 번도 실행되지 않은 것이다.
그 경우 이 단계를 건너뛰고 보고서에 "Zed 먼저 실행 필요"라고 남긴다.

- **keymap.json**: `zed/keymap-rider-style.json` 의 두 컨텍스트 블록(`Workspace`, `Editor`)을
  기존 배열에 병합한다. 파일이 없으면 그대로 복사한다.
  동일 키에 기존 바인딩이 있으면 건드리지 말고 충돌 목록에 기록한다.
- **snippets/csharp.json**: `zed/snippets/csharp.json` 복사. `snippets` 폴더가 없으면 생성.
- **settings.json**: 다음 내용을 병합한다.

```json
{
  "auto_install_extensions": { "csharp": true }
}
```

4단계에서 csharp-ls 설치에 **성공한 경우에만** 아래도 추가로 병합한다:

```json
{
  "languages": {
    "CSharp": { "language_servers": ["csharp-ls"] }
  }
}
```

### 4단계: csharp-ls 언어 서버 설치

1. `dotnet --version` 으로 .NET SDK 존재 확인. 없으면 이 단계를 건너뛰고
   보고서에 ".NET SDK 설치 필요: https://dotnet.microsoft.com/download" 기록.
2. `dotnet tool install --global csharp-ls`
   - "already installed" 오류가 나면 `dotnet tool update --global csharp-ls`
3. 새 셸에서 `csharp-ls --version` 으로 PATH 인식 확인.
   - 실패하면 `%USERPROFILE%\.dotnet\tools` 가 PATH에 있는지 검사하고 결과를 보고한다.
   - 사용자 폴더명에 한글이 포함되어 문제가 되는 경우, 영문 경로(`C:\dev` 등)에
     심볼릭 링크를 만드는 우회안을 보고서에 제안한다 (실행은 사용자 확인 후에만).

### 5단계: unity-zed 패키지 (외부 에디터 등록 + sln 생성)

1. `https://github.com/Edersteiner/zed-editor-for-unity` 저장소의 `package.json` 을
   확인해 정확한 패키지 이름을 얻는다 (예상: `com.maligan.unity-zed` 계열).
2. `<프로젝트>/Packages/manifest.json` 을 백업한 뒤, dependencies에
   `"<패키지이름>": "https://github.com/Edersteiner/zed-editor-for-unity.git"` 추가.
3. 네트워크 접근이 안 되면 이 단계는 수동 안내로 남긴다
   (Unity Package Manager → Add package from git URL).

### 6단계: Zed 확장 배치 (dev extension 준비)

- `zed-extension/` 폴더를 `<사용자 홈>/zed-dev-extensions/unity-csharp-kit/` 로 복사한다.
- `rustup --version` 또는 `cargo --version` 으로 Rust 툴체인 확인.
  없으면 보고서에 "https://rustup.rs 에서 설치 필요" 기록.
- 실제 확장 설치는 Zed UI에서만 가능하므로(명령 팔레트 → `zed: install dev extension`)
  사용자 수동 단계로 보고한다.

## 검증

1. 설치/수정한 모든 파일의 경로 목록을 출력한다.
2. Unity 에디터가 실행 중이면 `curl http://localhost:17890/status` 를 실행해
   브리지 동작을 확인하고 결과를 보고한다. (Unity가 꺼져 있으면 "Unity 실행 후
   Console에서 [ZedBridge] 서버 시작 로그 확인" 안내만 남긴다.)

## 최종 보고서 형식

다음을 표로 요약한다:
- 각 단계의 성공 / 실패 / 건너뜀 여부와 이유
- 키맵 충돌 목록 (있다면)
- 사용자가 직접 해야 할 남은 작업:
  1. Zed 명령 팔레트 → `zed: install dev extension` → `zed-dev-extensions/unity-csharp-kit` 선택
  2. Unity → Edit > Preferences > External Tools → External Script Editor를 Zed로 선택
  3. Unity를 열어 재컴파일 후 Console에서 `[ZedBridge] 서버 시작` 로그 확인
