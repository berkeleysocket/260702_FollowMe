# Zed Unity Kit — Zed를 Rider처럼

Rider의 핵심 경험을 Zed에서 재현하는 DIY 키트입니다.
아키텍처상 불가능한 부분(인스펙터/씬 뷰 임베드, 어태치 디버깅)은 정직하게 제외하고,
**"에디터를 떠나지 않고 Unity를 조작한다"** 는 경험 자체를 로컬 HTTP 브리지로 만들어 냅니다.

## 이 키트로 되는 것

- Zed에서 F5 → Unity 플레이, Shift+F5 → 정지 (Rider의 실행 버튼)
- Zed에서 Ctrl+Shift+B → 에셋 리프레시 + 재컴파일 (Rider의 자동 리프레시)
- Zed 터미널 패널에서 Unity Console 로그 확인 (실시간 감시 태스크 포함)
- Rider 단축키 이식 (Alt+Enter, Shift+F6, Ctrl+B, Alt+F7, Ctrl+W 확장 선택 등)
- Unity 스니펫 (`mono`, `so`, `sf`, `tryget`, `singleton` 등)
- Library/Temp 제외 등 Unity 프로젝트 최적화 설정
- **직접 만든 Zed 확장**으로 csharp-ls 언어 서버 연결 (Windows OmniSharp 문제 우회)
- `/menu` 엔드포인트 = 무한 확장 포인트 (아래 참고)

## 안 되는 것 (Rider가 계속 필요한 부분)

- 브레이크포인트 어태치 디버깅 — Zed는 아직 C# 네이티브 디버깅을 지원하지 않습니다
- 인스펙터/하이어라키/씬 뷰를 Zed 안에 띄우기
- ReSharper급 대규모 리팩토링

---

## 설치 (5단계)

### 0. (권장) Unity 외부 에디터 등록 + sln 생성

Zed를 Unity의 외부 스크립트 에디터로 등록하고 `.sln`/`.csproj`를 생성해 주는
커뮤니티 패키지가 있습니다. 언어 서버가 프로젝트를 인식하려면 이게 필요합니다.

- 원본: `https://github.com/maligan/unity-zed`
- **Windows 포크(권장)**: `https://github.com/Edersteiner/zed-editor-for-unity`

Package Manager → Add package from git URL 로 설치 후,
`Edit > Preferences > External Tools` 에서 Zed 선택.

### 1. 브리지 설치

`unity/Editor/ZedUnityBridge.cs` 를 프로젝트의 `Assets/Editor/` 폴더에 복사합니다.
컴파일이 끝나면 Console에 `[ZedBridge] 서버 시작: http://localhost:17890/` 이 뜹니다.

### 2. 언어 서버 (C# 인텔리센스)

먼저 마켓플레이스 C# 확장을 시도해 보세요 (`ctrl-shift-p` → extensions → csharp).
**Windows에서 OmniSharp이 동작하지 않으면** csharp-ls 경로로 가세요:

```
dotnet tool install --global csharp-ls
```

그다음 `zed-extension/` 폴더를 dev extension으로 설치:
명령 팔레트 → `zed: install dev extension` → `zed-extension` 폴더 선택.
(Rust 툴체인 필요: https://rustup.rs — Zed가 알아서 WASM으로 빌드합니다)

마지막으로 사용자 settings.json에 언어 서버 지정:

```json
"languages": {
  "CSharp": {
    "language_servers": ["csharp-ls"]
  }
}
```

### 3. 프로젝트 설정 + 태스크

Unity 프로젝트 루트에 `.zed` 폴더를 만들고:

- `zed/settings-unity.json` → `프로젝트/.zed/settings.json`
- `zed/tasks.json` → `프로젝트/.zed/tasks.json`

### 4. 키맵

`zed/keymap-rider-style.json` 내용을 사용자 keymap에 병합합니다.
(명령 팔레트 → `zed: open keymap`)

### 5. 스니펫

`zed/snippets/csharp.json` 을 Zed 스니펫 폴더에 복사:

- Windows: `%AppData%\Zed\snippets\csharp.json`
- macOS/Linux: `~/.config/zed/snippets/csharp.json`

파일명이 안 맞으면 명령 팔레트의 `snippets: configure snippets` 로
정확한 언어 파일명을 확인하세요.

---

## 사용법

| 키 | 동작 |
|---|---|
| `F5` / `Shift+F5` | Unity 플레이 / 정지 |
| `F6` | 일시정지 토글 |
| `Ctrl+Shift+B` | 리프레시 + 재컴파일 |
| `Ctrl+Shift+L` | Console 로그 보기 |
| `Alt+Enter` | 코드 액션 (Quick Fix) |
| `Shift+F6` | 이름 변경 |
| `Ctrl+B` / `Ctrl+Alt+B` | 정의 / 구현으로 이동 |
| `Alt+F7` | 사용처 찾기 |
| `Ctrl+W` | 선택 영역 확장 |
| `Ctrl+N` / `Ctrl+Shift+N` | 심볼 / 파일 검색 |

터미널에서 직접 확인할 수도 있습니다:

```
curl http://localhost:17890/status
curl http://localhost:17890/logs
```

---

## 확장 포인트: /menu = 나만의 Rider 기능 공장

브리지의 `/menu?path=...` 는 **임의의 Unity 메뉴 아이템**을 실행합니다.
즉, Unity 쪽에 `[MenuItem]` 하나 만들 때마다 Zed에서 호출 가능한 기능이 하나 늘어납니다.
에디터 툴을 직접 만들어 오셨으니, 이 조합이 사실상 "직접 만드는 플러그인 API"입니다.

예시 — 씬 저장 + 스크린샷 기능을 Zed 단축키로:

```csharp
// Assets/Editor/ZedCommands.cs
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public static class ZedCommands
{
    [MenuItem("Zed/Save All Scenes")]
    private static void SaveAllScenes()
    {
        EditorSceneManager.SaveOpenScenes();
        Debug.Log("[Zed] 모든 씬 저장 완료");
    }

    [MenuItem("Zed/Capture Screenshot")]
    private static void CaptureScreenshot()
    {
        ScreenCapture.CaptureScreenshot("screenshot.png", 2);
        Debug.Log("[Zed] 스크린샷 저장: screenshot.png");
    }
}
```

tasks.json에 추가:

```json
{
  "label": "Unity 💾 모든 씬 저장",
  "command": "curl -s \"http://localhost:17890/menu?path=Zed/Save%20All%20Scenes\"",
  "reveal": "never",
  "hide": "always"
}
```

이런 식으로 테스트 실행, 빌드 트리거, 특정 오브젝트 선택 등
Rider에서 부러웠던 기능을 하나씩 직접 채워 넣을 수 있습니다.

---

## 트러블슈팅

- **포트 충돌**: Unity 인스턴스를 여러 개 띄우면 두 번째부터 실패합니다.
  `ZedUnityBridge.cs`의 `ListenPrefix` 포트 번호를 바꾸세요.
- **HttpListener 접근 거부 (드묾)**: 관리자 권한 없이 localhost는 보통 허용되지만,
  막히면 관리자 터미널에서
  `netsh http add urlacl url=http://localhost:17890/ user=Everyone`
- **csharp-ls를 못 찾음**: dotnet 글로벌 툴 경로(`%USERPROFILE%\.dotnet\tools`)가
  PATH에 있는지 확인하세요. 사용자 폴더명에 한글이 있으면 문제가 될 수 있으니,
  그 경우 예전 MCP 때처럼 `C:\dev` 같은 영문 경로에 심볼릭 링크를 걸어 두는 방법이 있습니다.
- **어셈블리 간 자동완성이 안 됨**: 해당 파일을 한 번 열면 인식되는 알려진 증상이 있습니다.
- **인식이 이상하면**: 명령 팔레트 → `editor: restart language server`
