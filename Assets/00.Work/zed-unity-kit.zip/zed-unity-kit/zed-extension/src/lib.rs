// Unity C# Kit — 직접 만드는 Zed 확장
//
// 하는 일: PATH에서 csharp-ls(.NET 기반 C# 언어 서버)를 찾아 Zed에 연결합니다.
// Windows에서 OmniSharp 확장이 동작하지 않는 문제의 우회로이자,
// 나중에 커스텀 인자/환경변수를 붙이는 확장 포인트입니다.
//
// 사전 준비: dotnet tool install --global csharp-ls
// 설치 방법: Zed 명령 팔레트 → "zed: install dev extension" → 이 폴더 선택

use zed_extension_api::{self as zed, Result};

struct UnityCSharpKit;

impl zed::Extension for UnityCSharpKit {
    fn new() -> Self {
        Self
    }

    fn language_server_command(
        &mut self,
        _language_server_id: &zed::LanguageServerId,
        worktree: &zed::Worktree,
    ) -> Result<zed::Command> {
        let command = worktree.which("csharp-ls").ok_or_else(|| {
            "csharp-ls를 찾을 수 없습니다. 'dotnet tool install --global csharp-ls'로 설치한 뒤 Zed를 재시작하세요.".to_string()
        })?;

        Ok(zed::Command {
            command,
            args: vec![],
            env: Default::default(),
        })
    }
}

zed::register_extension!(UnityCSharpKit);
